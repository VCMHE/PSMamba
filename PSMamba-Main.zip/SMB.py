from __future__ import annotations
import torch.nn as nn
import torch
from mamba_ssm import Mamba
from torch.distributions.normal import Normal


def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution."""
    return nn.Conv3d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)


class Mamba_Layer(nn.Module):
    def __init__(self, dim, d_state=16, d_conv=4, expand=2, num_slices=None):
        super().__init__()
        self.dim = dim
        self.norm = nn.LayerNorm(dim)
        self.mamba = Mamba(
            d_model=dim,  # Model dimension d_model
            d_state=d_state,  # SSM state expansion factor
            d_conv=d_conv,  # Local convolution width
            expand=expand,  # Block expansion factor
        )

    def forward(self, x):
        B, C = x.shape[:2]
        x_skip = x
        assert C == self.dim
        n_tokens = x.shape[2:].numel()
        img_dims = x.shape[2:]
        x_flat = x.reshape(B, C, n_tokens).transpose(-1, -2)
        x_norm = self.norm(x_flat)
        x_mamba = self.mamba(x_norm)

        out = x_mamba.transpose(-1, -2).reshape(B, C, *img_dims)
        out = out + x_skip

        return out


class MlpChannel(nn.Module):
    def __init__(self,hidden_size, mlp_dim, ):
        super().__init__()
        self.fc1 = nn.Conv3d(hidden_size, mlp_dim, 1)
        self.act = nn.GELU()
        self.fc2 = nn.Conv3d(mlp_dim, hidden_size, 1)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
        return x

class SFE(nn.Module):
    def __init__(self, in_channles) -> None:
        super().__init__()

        self.proj = nn.Conv3d(in_channles, in_channles, 3, 1, 1)
        self.norm = nn.InstanceNorm3d(in_channles)
        self.nonliner = nn.ReLU()

        self.proj2 = nn.Conv3d(in_channles, in_channles, 3, 1, 1)
        self.norm2 = nn.InstanceNorm3d(in_channles)
        self.nonliner2 = nn.ReLU()

        self.proj3 = nn.Conv3d(in_channles//2, in_channles//2, 3, 1, 1)
        self.norm3 = nn.InstanceNorm3d(in_channles)
        self.nonliner3 = nn.ReLU()

        self.proj4 = nn.Conv3d(in_channles//2, in_channles, 1, 1, 0)
        self.norm4 = nn.InstanceNorm3d(in_channles)
        self.nonliner4 = nn.ReLU()

    def forward(self, x):

        x_residual = x
        x1 = self.proj(x)
        x1 = self.norm(x1)
        x1 = self.nonliner(x1)

        x1 = self.proj2(x1)
        x1 = self.norm2(x1)
        x1 = self.nonliner2(x1)

        u, v = x1.chunk(2, dim=1)

        u = self.proj3(u)
        u = self.norm3(u)
        u = self.nonliner3(u)
        x = u * v

        x = self.proj4(x)
        x = self.norm4(x)
        x = self.nonliner4(x)
        
        return x + x_residual

        
class SMambaBlock(nn.Module):
    def __init__(self, in_chans=1, dim=48, d_state=16, d_conv=4, expand=2):
        super().__init__()

        self.mamba = Mamba_Layer(dim=dim, d_state=d_state, d_conv=d_conv, expand=expand)
        self.sfe = SFE(dim)
        self.norm = nn.InstanceNorm3d(dim)
        self.mlp = MlpChannel(dim, 2 * dim)


    def forward(self, x):
        x = self.sfe(x)
        x = self.mamba(x)
        x = self.norm(x)
        x = self.mlp(x)
        
        return x


class ConvInsBlock(nn.Module):
    """
    Specific convolutional block followed by leakyrelu for unet.
    """

    def __init__(self, in_channels, out_channels,kernal_size=3, stride=1, padding=1, alpha=0.1):
        super().__init__()

        self.main = nn.Conv3d(in_channels, out_channels, kernal_size, stride, padding)
        self.norm = nn.InstanceNorm3d(out_channels)
        self.activation = nn.LeakyReLU(alpha)

    def forward(self, x):
        out = self.main(x)
        out = self.norm(out)
        out = self.activation(out)
        return out

class MambaDecoderBlock(nn.Module):
    def __init__(self, x_channel, y_channel, out_channel, d_state, d_conv, expand):
        super(MambaDecoderBlock, self).__init__()

        self.Swin1 = SMambaBlock(dim = x_channel + y_channel, d_state=d_state, d_conv=d_conv, expand=expand)
        self.Conv2 = ConvInsBlock(x_channel + y_channel, out_channel)
        self.RH = nn.Conv3d(out_channel, 3, 3, 1, 1)
        self.RH.weight = nn.Parameter(Normal(0, 1e-5).sample(self.RH.weight.shape))
        self.RH.bias = nn.Parameter(torch.zeros(self.RH.bias.shape))


    def forward(self, x, y):
        concat = torch.cat([x, y], dim=1)
        x = self.Swin1(concat)
        x = self.Conv2(x)
        flow = self.RH(x)
        return flow

