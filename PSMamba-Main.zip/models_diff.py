
import torch
import torch.nn as nn
import torch.nn.functional as nnf
from torch.distributions.normal import Normal
from SMB import MambaDecoderBlock

class SpatialTransformer(nn.Module):
    """
    N-D Spatial Transformer
    """

    def __init__(self, size, mode='bilinear'):
        super().__init__()

        self.mode = mode

        # create sampling grid
        vectors = [torch.arange(0, s) for s in size]
        grids = torch.meshgrid(vectors)
        grid = torch.stack(grids)
        grid = torch.unsqueeze(grid, 0)
        grid = grid.type(torch.FloatTensor)

        # registering the grid as a buffer cleanly moves it to the GPU, but it also
        # adds it to the state dict. this is annoying since everything in the state dict
        # is included when saving weights to disk, so the model files are way bigger
        # than they need to be. so far, there does not appear to be an elegant solution.
        # see: https://discuss.pytorch.org/t/how-to-register-buffer-without-polluting-state-dict
        self.register_buffer('grid', grid)

    def forward(self, src, flow):
        # new locations
        new_locs = self.grid + flow
        shape = flow.shape[2:]

        # need to normalize grid values to [-1, 1] for resampler
        for i in range(len(shape)):
            new_locs[:, i, ...] = 2 * (new_locs[:, i, ...] / (shape[i] - 1) - 0.5)

        # move channels dim to last position
        # also not sure why, but the channels need to be reversed
        if len(shape) == 2:
            new_locs = new_locs.permute(0, 2, 3, 1)
            new_locs = new_locs[..., [1, 0]]
        elif len(shape) == 3:
            new_locs = new_locs.permute(0, 2, 3, 4, 1)
            new_locs = new_locs[..., [2, 1, 0]]

        return nnf.grid_sample(src, new_locs, align_corners=True, mode=self.mode)


class VecInt(nn.Module):
    """
    Integrates a vector field via scaling and squaring.
    """

    def __init__(self, inshape, nsteps=7):
        super().__init__()

        assert nsteps >= 0, 'nsteps should be >= 0, found: %d' % nsteps
        self.nsteps = nsteps
        self.scale = 1.0 / (2 ** self.nsteps)
        self.transformer = SpatialTransformer(inshape)

    def forward(self, vec):
        vec = vec * self.scale
        for _ in range(self.nsteps):
            vec = vec + self.transformer(vec, vec)
        return vec

class ConvInsBlock(nn.Module):
    """
    Specific convolutional block followed by leakyrelu for unet.
    """

    def __init__(self, in_channels, out_channels,kernal_size=3, stride=1, padding=1, alpha=0.1):
        super().__init__()

        self.main = nn.Conv3d(in_channels, out_channels, kernal_size, stride, padding)
        self.norm = nn.InstanceNorm3d(out_channels)
        self.activation = nn.LeakyReLU(alpha)

    def forward(self, x):
        out = self.main(x)
        out = self.norm(out)
        out = self.activation(out)
        return out


class RMSNorm(torch.nn.Module):

    def __init__(
        self,
        dim: int,
        eps: float = 1e-6,
        add_unit_offset: bool = True,
    ):
        super().__init__()
        self.eps = eps
        self.add_unit_offset = add_unit_offset
        self.weight = nn.Parameter(torch.ones(dim))

    def _norm(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x):
        x = self._norm(x.float()).type_as(x)
        if self.add_unit_offset:
            output = x * (1 + self.weight)
        else:
            output = x * self.weight
        return output


class SEblock(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SEblock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.LeakyReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1, 1)
        y = x * y.expand(x.size())
        return y


class Encoder(nn.Module):
    """
    Main model
    """

    def __init__(self, in_channel=1, first_out_channel=4):
        super(Encoder, self).__init__()

        c = first_out_channel

        self.conv0 = nn.Sequential(
            ConvBlock(in_channel, c),
            ConvInsBlock(c, 2*c),
            ConvInsBlock(2*c, 2*c),
            SEblock(2*c)
        )

        self.conv1 = nn.Sequential(
            nn.AvgPool3d(2),
            ConvInsBlock(2 * c, 4 * c),
            ConvInsBlock(4 * c, 4 * c),
            SEblock(4 * c)
        )

        self.conv2 = nn.Sequential(
            nn.AvgPool3d(2),
            ConvInsBlock(4 * c, 8 * c),
            ConvInsBlock(8 * c, 8 * c),
            SEblock(8 * c)
        )

        self.conv3 = nn.Sequential(
            nn.AvgPool3d(2),
            ConvInsBlock(8 * c, 16* c),
            ConvInsBlock(16 * c, 16 * c),
            SEblock(16 * c)
        )

        self.conv4 = nn.Sequential(
            nn.AvgPool3d(2),
            ConvInsBlock(16 * c, 32 * c),
            ConvInsBlock(32 * c, 32 * c),
            SEblock(32 * c)
        )

    def forward(self, x):
        out0 = self.conv0(x)  # 1
        out1 = self.conv1(out0)  # 1/2
        out2 = self.conv2(out1)  # 1/4
        out3 = self.conv3(out2)  # 1/8
        out4 = self.conv4(out3)  # 1/8

        return out0, out1, out2, out3, out4


class ProjectionLayer(nn.Module):
    def __init__(self, in_channels, dim=6, norm=RMSNorm):
        super().__init__()
        self.norm = norm(dim)
        self.proj = nn.Linear(in_channels, dim)
        self.proj.weight = nn.Parameter(Normal(0, 1e-5).sample(self.proj.weight.shape))
        self.proj.bias = nn.Parameter(torch.zeros(self.proj.bias.shape))

    def forward(self, feat):
        feat = feat.permute(0, 2, 3, 4, 1)
        feat = self.norm(self.proj(feat))
        feat = feat.permute(0, 4, 1, 2, 3)
        return feat




class ConvBlock(nn.Module):
    """
    Specific convolutional block followed by leakyrelu for unet.
    """

    def __init__(self, in_channels, out_channels,kernal_size=3, stride=1, padding=1, alpha=0.1):
        super().__init__()

        self.main = nn.Conv3d(in_channels, out_channels, kernal_size, stride, padding)
        self.activation = nn.LeakyReLU(alpha)

    def forward(self, x):
        out = self.main(x)
        out = self.activation(out)
        return out


class PSMamba(nn.Module):
    def __init__(self,
                 inshape=(160,192,160),
                 norm_layer=RMSNorm,
                 in_channel=1,
                 channels=4,
                 d_state=16,
                 d_conv=4,
                 expand=2,
                 scale=1):
        super(PSMamba, self).__init__()
        self.channels = channels
        self.step = 7
        self.inshape = inshape
        self.d_state = d_state
        self.d_conv = d_conv
        self.expand = expand
        c = self.channels
        self.encoder = Encoder(in_channel=in_channel, first_out_channel=c)

        self.upsample_trilin = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)
        
        self.peblock1 = ProjectionLayer(2*c, dim=2*c, norm=norm_layer)
        self.mdb1 = MambaDecoderBlock(2*c, 2*c, 2*c, d_state=self.d_state, d_conv=self.d_conv, expand=self.expand)
        
        
        self.peblock2 = ProjectionLayer(4*c, dim=4*c, norm=norm_layer)
        self.mdb2 = MambaDecoderBlock(4*c, 4*c, 4*c, d_state=self.d_state, d_conv=self.d_conv, expand=self.expand)
        

        self.peblock3 = ProjectionLayer(8*c, dim=8*c, norm=norm_layer)
        self.mdb3 = MambaDecoderBlock(8*c, 8*c, 8*c, d_state=self.d_state, d_conv=self.d_conv, expand=self.expand)
        

        self.peblock4 = ProjectionLayer(16*c, dim=16*c, norm=norm_layer)
        self.mdb4 = MambaDecoderBlock(16*c, 16*c, 16*c, d_state=self.d_state, d_conv=self.d_conv, expand=self.expand)
        

        self.peblock5 = ProjectionLayer(32*c, dim=32*c, norm=norm_layer)
        self.mdb5 = MambaDecoderBlock(32*c, 32*c, 32*c, d_state=self.d_state, d_conv=self.d_conv, expand=self.expand)

        
        self.transformer = nn.ModuleList()
        self.integrate = nn.ModuleList()
        for i in range(5):
            self.transformer.append(SpatialTransformer([s // 2**i for s in inshape]))
            self.integrate.append(VecInt([s // 2 ** i for s in inshape], nsteps=self.step))

    def forward(self, moving, fixed):

        # encoding stage
        M1, M2, M3, M4, M5 = self.encoder(moving)
        F1, F2, F3, F4, F5 = self.encoder(fixed)

        # flow estimating stage
        
        f5, m5 = self.peblock5(F5), self.peblock5(M5)
        mx5 = m5
        flow = self.mdb5(f5, mx5)
        mx5 = self.transformer[4](m5, flow)
        w = self.mdb5(f5, mx5)
        flow = self.transformer[4](flow, w)+w
        mx5 = self.transformer[4](m5, flow)
        w = self.mdb5(f5, mx5)
        w = self.transformer[4](flow, w)+w
        
        w = self.integrate[4](w)
        flow = self.upsample_trilin(2*w)


        M4 = self.transformer[3](M4, flow)
        f4, m4 = self.peblock4(F4), self.peblock4(M4)
        w = self.mdb4(f4, m4)
        w = self.integrate[3](w)
        flow = self.upsample_trilin(2 *(self.transformer[3](flow, w)+w))

        
        M3 = self.transformer[2](M3, flow)
        f3, m3 = self.peblock3(F3), self.peblock3(M3)
        w = self.mdb3(f3, m3)
        w = self.integrate[2](w)
        flow = self.upsample_trilin(2 * (self.transformer[2](flow, w) + w))
        
        M2 = self.transformer[1](M2, flow)
        f2, m2 = self.peblock2(F2), self.peblock2(M2)
        w = self.mdb2(f2, m2)
        w = self.integrate[1](w)
        flow = self.upsample_trilin(2 * (self.transformer[1](flow, w) + w))
        
        M1 = self.transformer[0](M1, flow)
        f1, m1 = self.peblock1(F1), self.peblock1(M1)
        w = self.mdb1(f1, m1)
        w = self.integrate[0](w)
        flow = self.transformer[0](flow, w)+w
        
        y_moved = self.transformer[0](moving, flow)
        
        return y_moved, flow
