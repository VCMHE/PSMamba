#  Medical Image Registration via Spatial Feature Extraction Mamba and Substrate Iterative  Refinement

**Keywords：Deformable image registration, unsuper vised registration, Medical image registration.**


## Training and Inference
Train and Test
```python
python train.py 
```
```python
python infer.py 
```
## Implementation of the Variants
If you want to try the diffeomorphic method, please execute  train_diff:
```python
python train_diff.py 
```
```python
python infer_diff.py 

## Reference
<a href="https://github.com/voxelmorph/voxelmorph">VoxelMorph</a>,
<a href="https://github.com/junyuchen245/TransMorph_Transformer_for_Medical_Image_Registration">TransMorph</a>,
<a href="https://github.com/Torbjorn1997/PIViT">PIVIT</a>
and
<a href="https://github.com/ZAX130/SmileCode">ModeT</a>.

